import pandas as pd
from sklearn.preprocessing import StandardScaler

df = pd.read_csv("../data/logistics_data.csv")
df = df.drop_duplicates(subset=["order_id"])
df["order_date"] = pd.to_datetime(df["order_date"], errors="coerce")

df["load_kg"] = df["load_kg"].fillna(df["load_kg"].median())
df["vehicle_type"] = df["vehicle_type"].fillna("Unknown")

df["delay_minutes"] = df["actual_time_min"] - df["planned_time_min"]
df["on_time"] = (df["delay_minutes"] <= 5).astype(int)
df["utilization_rate"] = df["load_kg"] / df["capacity_kg"]
df["cost_per_km"] = df["total_transport_cost"] / df["distance_km"]

features = ["distance_km","load_kg","total_transport_cost","delay_minutes"]
scaler = StandardScaler()
df[features] = scaler.fit_transform(df[features])

df.to_csv("../data/logistics_data_clean.csv", index=False)
print("Preprocessing complete:", df.shape)
