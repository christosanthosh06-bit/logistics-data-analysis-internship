import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("../data/logistics_data.csv")
df["delay_minutes"] = df["actual_time_min"] - df["planned_time_min"]
df["on_time"] = (df["delay_minutes"] <= 5).astype(int)
df["utilization_rate"] = df["load_kg"] / df["capacity_kg"] * 100

print(df.describe())
print(df[["distance_km","actual_time_min","total_transport_cost","delay_minutes"]].corr())

plt.hist(df["actual_time_min"], bins=20)
plt.title("Delivery Time Distribution")
plt.xlabel("Delivery time (minutes)")
plt.ylabel("Frequency")
plt.tight_layout()
plt.savefig("../week3/charts/delivery_time_distribution.png")
plt.show()

plt.scatter(df["distance_km"], df["actual_time_min"])
plt.title("Distance vs Delivery Time")
plt.xlabel("Distance (km)")
plt.ylabel("Delivery time (minutes)")
plt.tight_layout()
plt.savefig("../week3/charts/distance_vs_time.png")
plt.show()
