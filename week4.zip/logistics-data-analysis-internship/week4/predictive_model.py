import pandas as pd
from sklearn.model_selection import train_test_split, KFold, cross_val_score
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

df = pd.read_csv("../data/logistics_data.csv")
features = ["distance_km","load_kg","traffic_level","weather_flag","quantity","vehicle_type"]
X, y = df[features], df["actual_time_min"]

X_train,X_test,y_train,y_test = train_test_split(
    X,y,test_size=0.20,random_state=42
)

pre = ColumnTransformer([
    ("num",StandardScaler(),["distance_km","load_kg","traffic_level","weather_flag","quantity"]),
    ("cat",OneHotEncoder(handle_unknown="ignore"),["vehicle_type"])
])

model = Pipeline([
    ("preprocess",pre),
    ("model",RandomForestRegressor(
        n_estimators=100,max_depth=10,min_samples_leaf=2,random_state=42))
])

model.fit(X_train,y_train)
pred = model.predict(X_test)

print("MAE:",mean_absolute_error(y_test,pred))
print("RMSE:",mean_squared_error(y_test,pred)**0.5)
print("R2:",r2_score(y_test,pred))

cv = KFold(n_splits=5,shuffle=True,random_state=42)
cv_mae = -cross_val_score(model,X,y,cv=cv,scoring="neg_mean_absolute_error").mean()
print("5-fold CV MAE:",cv_mae)
