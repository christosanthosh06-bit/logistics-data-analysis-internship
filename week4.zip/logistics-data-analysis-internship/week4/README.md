# Week 4 – Predictive Modeling and Optimization

This folder contains the predictive modeling report and Python implementation for delivery-time forecasting, model evaluation, cross-validation and route optimization planning.
