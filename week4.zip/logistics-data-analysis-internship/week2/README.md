# Week 2 – Data Collection, Cleaning & Preprocessing

This folder contains the Week 2 report and preprocessing workflow. The project uses a synthetic logistics dataset informed by public freight-data structures. See `data_preprocessing_report.docx` for the complete methodology.
