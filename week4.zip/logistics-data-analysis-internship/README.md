# Logistics Data Analysis Internship

## YuvaIntern – Logistics Data Analyst Internship

This repository contains the Week 1 strategic planning and data-analysis work for a logistics data analyst internship.

### Project
**Logistics Delivery Performance & Route Optimization**

The project studies delivery time, transportation cost, vehicle utilization, delays and route characteristics. The planned workflow uses Python for data cleaning, exploratory data analysis, regression, clustering and route optimization.

### Objectives
- Measure logistics performance using KPIs.
- Explore delivery and route patterns.
- Predict delivery time using regression.
- Segment routes using clustering.
- Propose route optimization using a Vehicle Routing Problem (VRP) approach.
- Translate analytical findings into logistics decisions.

### KPIs
1. On-Time Delivery Rate
2. Average Delivery Time
3. Cost per Delivery
4. Vehicle Utilization
5. Delay Rate
6. Average Route Distance
7. Order Fulfilment Rate

### Repository Structure
```text
data/       Sample logistics dataset
week1/      Week 1 report and integrated analysis
analysis/   Individual analysis scripts
outputs/    Output notes
```

### How to Run
```bash
pip install -r requirements.txt
python week1/logistics_analysis.py
python analysis/eda.py
python analysis/regression.py
python analysis/clustering.py
python analysis/route_optimization.py
```

### Dataset
The included CSV is a **synthetic educational dataset** created for demonstrating the internship workflow. Public sources such as the U.S. Bureau of Transportation Statistics Freight Analysis Framework and Commodity Flow Survey are used as research references.

### Public Research Sources
- BTS Freight Analysis Framework: https://www.bts.gov/faf
- BTS Freight Indicators: https://www.bts.gov/freight-indicators
- U.S. Census Commodity Flow Survey: https://www.census.gov/programs-surveys/cfs.html

### Author
Christo Santhosh

> This repository is an academic/internship demonstration project and does not represent a real company's confidential logistics data.

### Week 4
Predictive delivery-time modeling, cross-validation, model evaluation and logistics optimization.
