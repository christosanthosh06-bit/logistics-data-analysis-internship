# Outputs

This folder is reserved for charts, model evaluation results and optimization comparisons produced during later internship tasks.
