import pandas as pd

df = pd.read_csv("data/logistics_data.csv")
df["delay_minutes"] = df["actual_time_min"] - df["planned_time_min"]
df["on_time"] = (df["delay_minutes"] <= 5).astype(int)

print("Rows:", len(df))
print("\nKPI SUMMARY")
print("On-time delivery rate:", round(df["on_time"].mean()*100, 2), "%")
print("Average delivery time:", round(df["actual_time_min"].mean(), 2), "minutes")
print("Average cost per delivery:", round(df["total_transport_cost"].mean(), 2))
print("Average distance:", round(df["distance_km"].mean(), 2), "km")
print("Delay rate:", round((1-df["on_time"].mean())*100, 2), "%")

util = (df["load_kg"] / df["capacity_kg"] * 100).mean()
print("Average vehicle utilization:", round(util, 2), "%")
