import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, r2_score

df = pd.read_csv("data/logistics_data.csv")
features = ["distance_km","load_kg","traffic_level","weather_flag"]
X = df[features]
y = df["actual_time_min"]

X_train,X_test,y_train,y_test = train_test_split(
    X,y,test_size=0.2,random_state=42
)
model = LinearRegression()
model.fit(X_train,y_train)
pred = model.predict(X_test)

print("Mean Absolute Error:", round(mean_absolute_error(y_test,pred),2))
print("R2 Score:", round(r2_score(y_test,pred),3))
print("Coefficients:")
print(dict(zip(features,model.coef_)))
