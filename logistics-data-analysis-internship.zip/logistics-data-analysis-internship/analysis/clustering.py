import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans

df = pd.read_csv("data/logistics_data.csv")
df["delay_minutes"] = df["actual_time_min"] - df["planned_time_min"]

features = df[["distance_km","delay_minutes","total_transport_cost","quantity"]].fillna(0)
scaled = StandardScaler().fit_transform(features)

model = KMeans(n_clusters=4,n_init=10,random_state=42)
df["route_cluster"] = model.fit_predict(scaled)

print(df.groupby("route_cluster")[features.columns].mean().round(2))
