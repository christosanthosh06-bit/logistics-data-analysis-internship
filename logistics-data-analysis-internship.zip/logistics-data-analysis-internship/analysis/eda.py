import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("data/logistics_data.csv")
df["delay_minutes"] = df["actual_time_min"] - df["planned_time_min"]

print(df.describe(numeric_only=True))
print("\nAverage delay by vehicle type:")
print(df.groupby("vehicle_type")["delay_minutes"].mean())

plt.figure(figsize=(8,5))
plt.hist(df["delay_minutes"], bins=20)
plt.xlabel("Delay (minutes)")
plt.ylabel("Number of deliveries")
plt.title("Distribution of Delivery Delays")
plt.tight_layout()
plt.savefig("outputs/delay_distribution.png")
plt.show()
